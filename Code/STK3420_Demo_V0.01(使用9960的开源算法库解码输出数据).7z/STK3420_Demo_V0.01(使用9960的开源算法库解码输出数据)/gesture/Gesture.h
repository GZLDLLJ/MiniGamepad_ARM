#ifndef _GESTURE_H
#define _GESTURE_H

#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>

#define DIRECTION_4
// #define DIRECTION_8

#define CTTRACK_RATIO_RISE 8
#define CTTRACK_RATIO_FALL 2
#define CTTRACK_RATIO_STEP 32
#define CTTRACK_STABLE_TH 12
#define CTTRACK_STABLE_CNT 10
#define CTTRACK_UNSTABLE_TH 20
#define CTTRACK_UNSTABLE_CNT 48
#define CTTRACK_OFFSET_WAIT_CNT 0
#define GESTURE_COMBO_CNT 0
#define GESTURE_AXIS2_EN 1
#define GESTURE_AXIS1_EN 1
//#define GESTURE_INTP 32
#define GESTURE_INTP 8
#define GESTURE_CH1_RATIO_M 1
#define GESTURE_CH1_RATIO_N 1
#define GESTURE_CH0_TH 7
#define GESTURE_CH1_TH 7
#define GESTURE_CH2_TH 7
#define GESTURE_CH3_TH 7
#define GESTURE_CORR_TH 500
#define GESTURE_BUF_SZ (32*(GESTURE_INTP_LIMIT+1))
#define GESTURE_PHASE_RANGE (4*(GESTURE_INTP_LIMIT+1))
#define GESTURE_QBIT 16
#define GESTURE_QSTEP 4
#define GESTURE_SIGNAL_CNT 1
#define GESTURE_SIGNAL_NF_CNT 8
#define GESTURE_NF_MAX_CNT 32
#define GESTURE_NF_MIN_CNT 1
#define GESTURE_QMAX (1<<GESTURE_QBIT)-1
#define GESTURE_PHASE_ZERO GESTURE_PHASE_RANGE
#define GESTURE_PHASE_MAX (GESTURE_PHASE_RANGE*2+1)

//#define GESTURE_INTP_LIMIT 32
#define GESTURE_INTP_LIMIT 8
#define GESTURE_BUF_SZ_LIMIT (36*(GESTURE_INTP_LIMIT+1))
#define GESTURE_PHASE_MAX_LIMIT ((8*(GESTURE_INTP_LIMIT+1))*2+1)

#define bGesture_ChkSignal(p, a, i, s, th) ( (s - p->xtCTTrack[a].iInt[i]) > th)
#define iCTTrack_GetInt(p, ch)  ((p)->iInt[ch])

#define GESTURE_EVENT_UL    (GESTURE_EVENT_UP | GESTURE_EVENT_LEFT)
#define GESTURE_EVENT_UR    (GESTURE_EVENT_UP | GESTURE_EVENT_RIGHT)
#define GESTURE_EVENT_DL    (GESTURE_EVENT_DOWN | GESTURE_EVENT_LEFT)
#define GESTURE_EVENT_DR    (GESTURE_EVENT_DOWN | GESTURE_EVENT_RIGHT)
#define GESTURE_EVENT_AR    (GESTURE_EVENT_UP | GESTURE_EVENT_DOWN)

enum {
    DCLICK_STATE_INIT = 0,
    DCLICK_STATE_START,
    DCLICK_STATE_1STNEAR,
    DCLICK_STATE_1STFAR,
    DCLICK_STATE_2NDNEAR,
    DCLICK_STATE_END,
};

enum {
    DCLICK_STATE_NEAR = 0,
    DCLICK_STATE_FAR
};

enum {
    GESTURE_STATE_INIT = 0,
    GESTURE_STATE_IDLE,
    GESTURE_STATE_SIGNAL,
    GESTURE_STATE_SIGNAL_NF,
    GESTURE_STATE_SIGNAL_END,
    GESTURE_STATE_HOLD,
};

enum {
    CTTRACK_STATE_INIT = 0,
    CTTRACK_STATE_UNSTABLE,
    CTTRACK_STATE_STABLE,
};

enum {
    GESTURE_MAP_LEFT_RIGHT_UP_DOWN = 0,
    GESTURE_MAP_45_DEG_UP_DOW_LEFT_RIGHT,
};

enum {
    GESTURE_EVENT_NA = 0x00,
    GESTURE_EVENT_NF = 0x01,

    GESTURE_EVENT_UP = 0x02,
    GESTURE_EVENT_DOWN = 0x04,
    GESTURE_EVENT_LEFT = 0x08,
    GESTURE_EVENT_RIGHT = 0x10,
    GESTURE_EVENT_DIR_MASK = 0x1E,
};

typedef struct tagCTTrack
{
    int iVal[2];
    int iInt[2];

    int iDiff[2];

    uint8_t iState;
    int iCnt;
    int iStepCnt[2];

} tfCTTrack;

typedef struct tagGesture{
    tfCTTrack xtCTTrack[2];
    // Ring Buffer
    int16_t iBuf[4][GESTURE_BUF_SZ_LIMIT];
    uint16_t iPtr;

    // Cross-Correlation Results
    int32_t iCor[2][GESTURE_PHASE_MAX_LIMIT];
    int iMaxCorr[2], iMaxPhase[2];
    //int iSpeed;
    //int iGesLen;
    //int iAngle;

    // Gesture Detection
    uint8_t iMapIdx;

    // Statemachine
    uint8_t iState;
    uint8_t iPrevState;
    uint16_t iCnt;

    // Signal Interpolation
    int iLastVal[4];
    int iIntp[4][GESTURE_INTP_LIMIT];

    // double click
    bool gbGesDC_En;
    bool gbGesDC_NF; //0:near, 1:Far
    int giGesDC_NTHD;
    int giGesDC_FTHD;
    int giGesDC_State; //0:未進mode, 1:1st near, 2:1st far, 3:2st near, 4:成立, 回到0
    int giGesDC_DebounceCnt;
    int giGesDC_Debounce;
    int gdGesDC_Timeout;
    int gdGesDC_TimeStamp;
} tfGesture;

void Gesture_Init(tfGesture *ptInst);
int iGesture_Do(tfGesture *ptInst, int iCh0, int iCh1, int iCh2, int iCh3);
int iGesDC_Do(tfGesture *ptInst, int iCh0, int iCh1, int iCh2, int iCh3);
int iGesDC_ChkTimeout(tfGesture *ptInst, int time_interval);
void Gesture_IntpEnq(tfGesture *ptInst, int iCh0, int iCh1, int iCh2, int iCh3, int iIntp);
int iGesture_Interpolation(int x1, int x2, int y1, int y2, int x);
void Gesture_Enq(tfGesture *ptInst, int iCh0, int iCh1, int iCh2, int iCh3);
int iGesture_Quantize(int iVal, int iTh);
void Gesture_DoCorr(tfGesture *ptInst, int iAx);
int iGesture_Detect(tfGesture *ptInst);

void CTTrack_Init(tfCTTrack *ptInst);
int iCTTrack_Do(tfCTTrack *ptInst, int iCh0, int iCh1);
void CTTrack_DoTrack(tfCTTrack *ptInst, int iCh0, int iCh1);

int iATan2(int iY, int iX);
int iATan2_Pos(int iY, int iX);
int iATan2_Search(int iTan);

#endif
