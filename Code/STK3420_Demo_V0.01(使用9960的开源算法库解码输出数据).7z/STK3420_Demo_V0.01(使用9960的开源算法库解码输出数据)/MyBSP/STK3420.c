/**
  ******************************************************************************
  * @file           : SC7LC32.c
  * @brief          : SC7LC32 Driver
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2023 YSpringTech Inc.
      * δ���������ɣ��������������κ���;
      * ��������:2023/6/14
      * �汾��V1.0
      * ��Ȩ���У�����ؾ���
  * Copyright(C) �����л㴺�Ƽ��ɷ����޹�˾ YSpringTech Inc.
  * All rights reserved
  *
  ******************************************************************************
  */
#include <STK3420.h>
#include "I2C.h"
#include "stdlib.h"
#include "Gesture.h"

/****************************************************************************************************
* Declaration Initiation Setting ��ʼ��
****************************************************************************************************/
stk342x_register_table stk342x_default_register_table[] =
{

    {STK342X_REG_PSGSCTRL1,         (STK342X_PS_PRS1 | STK342X_PSGS_IT390),                       0xFF},
    {STK342X_REG_ALSCTRL1,          (STK342X_ALS_PRS1 | STK342X_ALS_GAIN1 | STK342X_ALS_IT50),  0xFF},
    {STK342X_REG_LEDCTRL,           STK342X_LED_150mA,                                          0xFF},
    {STK342X_REG_PSGSCTRL2,         0xF3,                                                       0xFF},
    {STK342X_REG_WAIT1_PSGS,        0x06,                                                       0xFF},
    {STK342X_REG_ALSCTRL2,          0x50,                                                       0xFF},
    {STK342X_REG_WAIT_ALS,          0x00,                                                       0xFF},
    {0x95,                          0x90,                                                       0xFF},
    {STK342X_REG_MISC1,             0x35,                                                       0xFF},
};

gesture_data_type gesture_data_;
int gesture_ud_delta_;
int gesture_lr_delta_;
int gesture_ud_count_;
int gesture_lr_count_;
int gesture_near_count_;
int gesture_far_count_;
int gesture_state_;
int gesture_motion_;

void resetGestureParameters(void)
{
    gesture_data_.index = 0;
    gesture_data_.total_gestures = 0;

    gesture_ud_delta_ = 0;
    gesture_lr_delta_ = 0;

    gesture_ud_count_ = 0;
    gesture_lr_count_ = 0;

    gesture_near_count_ = 0;
    gesture_far_count_ = 0;

    gesture_state_ = 0;
    gesture_motion_ = DIR_NONE;
}

static int32_t stk342x_init_all_reg(void)
{
    int32_t ret = 0;
    uint16_t reg_count = 0, reg_num = sizeof(stk342x_default_register_table) / sizeof(stk342x_register_table);

    for (reg_count = 0; reg_count < reg_num; reg_count++)
    {
        AT24CXX_WriteOneByte(stk342x_default_register_table[reg_count].address,
                                   stk342x_default_register_table[reg_count].value);
    }


    return ret;
}


static void stk342x_enable_gs( FunctionalState en)
{

    uint8_t reg_value = 0;

    resetGestureParameters();
    reg_value = AT24CXX_ReadOneByte( STK342X_REG_STATE);



    reg_value &= (~(STK342X_STATE_EN_WAIT_PSGS_MASK));

    if (en)
    {
        reg_value |= STK342X_STATE_EN_WAIT_PSGS_MASK;
    }

    AT24CXX_WriteOneByte(STK342X_REG_STATE,reg_value);
}

void HW_STK3420_Init(void)
{
    u8 temp=0;
    IIC_Init(100000, STK3420_SLAVEADDR);
    Delay_Ms(500);
    temp=AT24CXX_ReadOneByte(STK342X_REG_PDT_ID);
    if(temp==0x50)
    {
        printf("PID=%x\r\n",temp);
    }else{
        printf("PDT_ID EEOR!!\r\n");

    }
    stk342x_init_all_reg();
    stk342x_enable_gs(ENABLE);




}



/* ----------------------------------------------------------------------------*
 *
 *  Function Name : processGestureData(void)
 *
 *  Description  :Processes the raw gesture data to determine swipe direction
 *
 *  Input : None
 *
 *  Output : None
 *
 *  Return : True if near or far state seen. False otherwise.
 * ----------------------------------------------------------------------------*
 * Authors: Sarath S
 * Date: May 17, 2017
 * ---------------------------------------------------------------------------*/
int processGestureData(void)
{
    uint8_t u_first = 0;
    uint8_t d_first = 0;
    uint8_t l_first = 0;
    uint8_t r_first = 0;
    uint8_t u_last = 0;
    uint8_t d_last = 0;
    uint8_t l_last = 0;
    uint8_t r_last = 0;
    int ud_ratio_first;
    int lr_ratio_first;
    int ud_ratio_last;
    int lr_ratio_last;
    int ud_delta;
    int lr_delta;
    int i;

    /* If we have less than 4 total gestures, that's not enough */
    if( gesture_data_.total_gestures <= 4 ) {
        printf("total_gestures=%d",gesture_data_.total_gestures);
        return false;
    }

    /* Check to make sure our data isn't out of bounds */
    if( (gesture_data_.total_gestures <= 32) && \
        (gesture_data_.total_gestures > 0) ) {

        /* Find the first value in U/D/L/R above the threshold */
        for( i = 0; i < gesture_data_.total_gestures; i++ ) {
            if( (gesture_data_.u_data[i] > GESTURE_THRESHOLD_OUT) &&
                (gesture_data_.d_data[i] > GESTURE_THRESHOLD_OUT) &&
                (gesture_data_.l_data[i] > GESTURE_THRESHOLD_OUT) &&
                (gesture_data_.r_data[i] > GESTURE_THRESHOLD_OUT) ) {

                u_first = gesture_data_.u_data[i];
                d_first = gesture_data_.d_data[i];
                l_first = gesture_data_.l_data[i];
                r_first = gesture_data_.r_data[i];
                break;
            }
        }

        /* If one of the _first values is 0, then there is no good data */
        if( (u_first == 0) || (d_first == 0) || \
            (l_first == 0) || (r_first == 0) ) {

            return false;
        }
        /* Find the last value in U/D/L/R above the threshold */
        for( i = gesture_data_.total_gestures - 1; i >= 0; i-- ) {
#if 1
            printf("Finding last: ");
            printf("U:%x",gesture_data_.u_data[i]);
            printf(" D:%x",gesture_data_.d_data[i]);
            printf(" L:%x",gesture_data_.l_data[i]);
            printf(" R:%x",gesture_data_.r_data[i]);
            printf("\r\n");
#endif
            if( (gesture_data_.u_data[i] > GESTURE_THRESHOLD_OUT) &&
                (gesture_data_.d_data[i] > GESTURE_THRESHOLD_OUT) &&
                (gesture_data_.l_data[i] > GESTURE_THRESHOLD_OUT) &&
                (gesture_data_.r_data[i] > GESTURE_THRESHOLD_OUT) ) {

                u_last = gesture_data_.u_data[i];
                d_last = gesture_data_.d_data[i];
                l_last = gesture_data_.l_data[i];
                r_last = gesture_data_.r_data[i];
                break;
            }
        }
    }

    /* Calculate the first vs. last ratio of up/down and left/right */
    ud_ratio_first = ((u_first - d_first) * 100) / (u_first + d_first);
    lr_ratio_first = ((l_first - r_first) * 100) / (l_first + r_first);
    ud_ratio_last = ((u_last - d_last) * 100) / (u_last + d_last);
    lr_ratio_last = ((l_last - r_last) * 100) / (l_last + r_last);

#if 0
    printf("Last Values: ");
    printf("U:%x",u_last);
    printf(" D:%x",d_last);
    printf(" L:%x",l_last);
    printf(" R:%x",r_last);
    printf("\r\n");

    printf("Ratios: ");
    printf("UD Fi: %x",ud_ratio_first);
    printf(" UD La: %x",ud_ratio_last);
    printf(" LR Fi: %x",lr_ratio_first);
    printf(" LR La: %x",lr_ratio_last);
    printf("\r\n");

#endif

    /* Determine the difference between the first and last ratios */
    ud_delta = ud_ratio_last - ud_ratio_first;
    lr_delta = lr_ratio_last - lr_ratio_first;

#if 0
    printf("Deltas: ");
    printf("UD: ");
    debugPutChar(ud_delta);
    printf(" LR: ");
    debugPutChar(lr_delta);
    printf("\r\n");
#endif

    /* Accumulate the UD and LR delta values */
    gesture_ud_delta_ += ud_delta;
    gesture_lr_delta_ += lr_delta;

#if DEBUGPRINT
    printf("Accumulations: ");
    printf("UD: ");
    debugPutChar(gesture_ud_delta_);
    printf(" LR: ");
    debugPutChar(gesture_lr_delta_);
    printf("\r\n");
#endif

    /* Determine U/D gesture */
    if( gesture_ud_delta_ >= GESTURE_SENSITIVITY_1 ) {
        gesture_ud_count_ = 1;
    } else if( gesture_ud_delta_ <= -GESTURE_SENSITIVITY_1 ) {
        gesture_ud_count_ = -1;
    } else {
        gesture_ud_count_ = 0;
    }

    /* Determine L/R gesture */
    if( gesture_lr_delta_ >= GESTURE_SENSITIVITY_1 ) {
        gesture_lr_count_ = 1;
    } else if( gesture_lr_delta_ <= -GESTURE_SENSITIVITY_1 ) {
        gesture_lr_count_ = -1;
    } else {
        gesture_lr_count_ = 0;
    }

    /* Determine Near/Far gesture */
    if( (gesture_ud_count_ == 0) && (gesture_lr_count_ == 0) ) {
        if( (abs(ud_delta) < GESTURE_SENSITIVITY_2) && \
            (abs(lr_delta) < GESTURE_SENSITIVITY_2) ) {

            if( (ud_delta == 0) && (lr_delta == 0) ) {
                gesture_near_count_++;
            } else if( (ud_delta != 0) || (lr_delta != 0) ) {
                gesture_far_count_++;
            }

            if( (gesture_near_count_ >= 10) && (gesture_far_count_ >= 2) ) {
                if( (ud_delta == 0) && (lr_delta == 0) ) {
                    gesture_state_ = NEAR_STATE;
                } else if( (ud_delta != 0) && (lr_delta != 0) ) {
                    gesture_state_ = FAR_STATE;
                }
                return true;
            }
        }
    } else {
        if( (abs(ud_delta) < GESTURE_SENSITIVITY_2) && \
            (abs(lr_delta) < GESTURE_SENSITIVITY_2) ) {

            if( (ud_delta == 0) && (lr_delta == 0) ) {
                gesture_near_count_++;
            }

            if( gesture_near_count_ >= 10 ) {
                gesture_ud_count_ = 0;
                gesture_lr_count_ = 0;
                gesture_ud_delta_ = 0;
                gesture_lr_delta_ = 0;
            }
        }
    }

#if DEBUGPRINT
    printf("UD_CT: ");
    debugPutChar(gesture_ud_count_);
    printf(" LR_CT: ");
    debugPutChar(gesture_lr_count_);
    printf(" NEAR_CT: ");
    debugPutChar(gesture_near_count_);
    printf(" FAR_CT: ");
    debugPutChar(gesture_far_count_);
    printf("----------");
#endif

    return false;
}/* End of this function */

/* ----------------------------------------------------------------------------*
 *
 *  Function Name : decodeGesture(void)
 *
 *  Description  :Determines swipe direction or near/far state
 *
 *  Input : None
 *
 *  Output : None
 *
 *  Return : True if near/far event. False otherwise.
 * ----------------------------------------------------------------------------*
 * Authors: Sarath S
 * Date: May 17, 2017
 * ---------------------------------------------------------------------------*/
int decodeGesture(void)
{
    /* Return if near or far event is detected */
    if( gesture_state_ == NEAR_STATE ) {
        gesture_motion_ = DIR_NEAR;
        return true;
    } else if ( gesture_state_ == FAR_STATE ) {
        gesture_motion_ = DIR_FAR;
        return true;
    }

    /* Determine swipe direction */
    if( (gesture_ud_count_ == -1) && (gesture_lr_count_ == 0) ) {
        gesture_motion_ = DIR_UP;
    } else if( (gesture_ud_count_ == 1) && (gesture_lr_count_ == 0) ) {
        gesture_motion_ = DIR_DOWN;
    } else if( (gesture_ud_count_ == 0) && (gesture_lr_count_ == 1) ) {
        gesture_motion_ = DIR_RIGHT;
    } else if( (gesture_ud_count_ == 0) && (gesture_lr_count_ == -1) ) {
        gesture_motion_ = DIR_LEFT;
    } else if( (gesture_ud_count_ == -1) && (gesture_lr_count_ == 1) ) {
        if( abs(gesture_ud_delta_) > abs(gesture_lr_delta_) ) {
            gesture_motion_ = DIR_UP;
        } else {
            gesture_motion_ = DIR_RIGHT;
        }
    } else if( (gesture_ud_count_ == 1) && (gesture_lr_count_ == -1) ) {
        if( abs(gesture_ud_delta_) > abs(gesture_lr_delta_) ) {
            gesture_motion_ = DIR_DOWN;
        } else {
            gesture_motion_ = DIR_LEFT;
        }
    } else if( (gesture_ud_count_ == -1) && (gesture_lr_count_ == -1) ) {
        if( abs(gesture_ud_delta_) > abs(gesture_lr_delta_) ) {
            gesture_motion_ = DIR_UP;
        } else {
            gesture_motion_ = DIR_LEFT;
        }
    } else if( (gesture_ud_count_ == 1) && (gesture_lr_count_ == 1) ) {
        if( abs(gesture_ud_delta_) > abs(gesture_lr_delta_) ) {
            gesture_motion_ = DIR_DOWN;
        } else {
            gesture_motion_ = DIR_RIGHT;
        }
    } else {
        return false;
    }

    return true;
}/* End of this function */

/* ----------------------------------------------------------------------------*
 *
 *  Function Name : readGesture(void)
 *
 *  Description  :Processes a gesture event and returns best guessed gesture
 *
 *  Input : None
 *
 *  Output : None
 *
 *  Return : Number corresponding to gesture. -1 on error.
 * ----------------------------------------------------------------------------*
 * Authors: Sarath S
 * Date: May 17, 2017
 * ---------------------------------------------------------------------------*/
int readGesture(void)
{


    uint8_t reg_value[8];
    uint8_t gstatus;
    int motion;
    int i;



    /* Keep looping as long as gesture data is valid */
    while(1) {

        /* Wait some time to collect next batch of FIFO data */
        Delay_Ms(2);

        gstatus=AT24CXX_ReadOneByte(STK342X_REG_GS_FLAG)& 0x1F;

        /* If we have valid data, read in FIFO */
        if( gstatus  > 0 ) {


            for (i = 0; i < gstatus; i++)
              {
                AT24CXX_Read(STK342X_REG_DATA1_GSE, &reg_value[0],8);

                gesture_data_.u_data[gesture_data_.index] = (reg_value[0] << 8 | reg_value[1]);
                gesture_data_.d_data[gesture_data_.index] = (reg_value[2] << 8 | reg_value[3]);
                gesture_data_.l_data[gesture_data_.index] = (reg_value[4] << 8 | reg_value[5]);
                gesture_data_.r_data[gesture_data_.index] = (reg_value[6] << 8 | reg_value[7]);
//                printf("u:%x,d:%x,l:%x,r:%x\r\n",
//                        gesture_data_.u_data[gesture_data_.index],
//                        gesture_data_.d_data[gesture_data_.index],
//                        gesture_data_.l_data[gesture_data_.index],
//                        gesture_data_.r_data[gesture_data_.index] );

                gesture_data_.index++;
                gesture_data_.total_gestures++;

            }
            /* Filter and process gesture data. Decode near/far state */
            if( processGestureData() ) {
                if( decodeGesture() ) {
                }
            }
            /* Reset data */
            gesture_data_.index = 0;
            gesture_data_.total_gestures = 0;


        } else {

            /* Determine best guessed gesture and clean up */

            decodeGesture();
            motion = gesture_motion_;
#if DEBUGPRINT
            printf("END: ");
            debugPutChar(gesture_motion_);
#endif
            resetGestureParameters();
            return motion;
        }
    }
}


void HW_SC7L32_Handler(void)
{

    switch (readGesture()) {
        case DIR_UP:
          printf("Gesture Up....!\r\n");
          break;
        case DIR_DOWN:
            printf("Gesture Down....!\r\n");
          break;
        case DIR_LEFT:
            printf("Gesture Left....!\r\n");
          break;
        case DIR_RIGHT:
            printf("Gesture Right....!\r\n");
          break;
        case DIR_NEAR:
            printf("Gesture Near....!\r\n");
          break;
        case DIR_FAR:
            printf("Gesture Far....!\r\n");
          break;

      }

}


