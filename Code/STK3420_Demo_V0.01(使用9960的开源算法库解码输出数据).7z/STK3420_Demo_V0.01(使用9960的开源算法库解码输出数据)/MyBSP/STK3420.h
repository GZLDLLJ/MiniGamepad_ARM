/**
  ******************************************************************************
  * @file           : SC7LC32.h
  * @brief          : SC7LC32 Driver
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2023 YSpringTech Inc.
      * δ���������ɣ��������������κ���;
      * ��������:2023/6/14
      * �汾��V1.0
      * ��Ȩ���У�����ؾ���
  * Copyright(C) �����л㴺�Ƽ��ɷ����޹�˾ YSpringTech Inc.
  * All rights reserved
  *
  ******************************************************************************
  */

#ifndef MYBSP_STK3420_H_
#define MYBSP_STK3420_H_
#include "debug.h"

#define  DEBUGPRINT     0
//�ӻ���ַ
#define  STK3420_SLAVEADDR      (0x58<<1)

/* Gesture parameters */
#define GESTURE_THRESHOLD_OUT   10
#define GESTURE_SENSITIVITY_1   50
#define GESTURE_SENSITIVITY_2   20

/* Define Register Map */
#define STK342X_REG_STATE                   0x00
#define STK342X_REG_PSGSCTRL1               0x01
#define STK342X_REG_ALSCTRL1                0x02
#define STK342X_REG_LEDCTRL                 0x03
#define STK342X_REG_INT                     0x04
#define STK342X_REG_WAIT1_PSGS              0x05
#define STK342X_REG_THDH1_PS                0x06
#define STK342X_REG_THDH2_PS                0x07
#define STK342X_REG_THDL1_PS                0x08
#define STK342X_REG_THDL2_PS                0x09
#define STK342X_REG_THDH1_ALS               0x0A
#define STK342X_REG_THDH2_ALS               0x0B
#define STK342X_REG_THDL1_ALS               0x0C
#define STK342X_REG_THDL2_ALS               0x0D
#define STK342X_REG_FLAG                    0x10
#define STK342X_REG_DATA1_PS                0x11
#define STK342X_REG_DATA2_PS                0x12
#define STK342X_REG_DATA1_ALS               0x13
#define STK342X_REG_DATA2_ALS               0x14
#define STK342X_REG_DATA1_IRS               0x17
#define STK342X_REG_DATA2_IRS               0x18
#define STK342X_REG_ALSCTRL2                0x19
#define STK342X_REG_WAIT_ALS                0x1B
#define STK342X_REG_WAIT2_PS                0x1C
#define STK342X_REG_PSGSCTRL2               0x1D
#define STK342X_REG_GS_FLAG                 0x1E
#define STK342X_REG_GS_FIFO_CTRL            0x1F
#define STK342X_REG_DATA1_GSE               0x20
#define STK342X_REG_DATA2_GSE               0x21
#define STK342X_REG_DATA1_GSW               0x22
#define STK342X_REG_DATA2_GSW               0x23
#define STK342X_REG_DATA1_GSN               0x24
#define STK342X_REG_DATA2_GSN               0x25
#define STK342X_REG_DATA1_GSS               0x26
#define STK342X_REG_DATA2_GSS               0x27
#define STK342X_REG_PDT_ID                  0x3E
#define STK342X_REG_RSRVD                   0x3F
#define STK342X_REG_SW_RESET                0x80
#define STK342X_REG_MISC1                   0x94

/* Define state reg */

#define STK342X_STATE_EN_CT_AUTOK_SHIFT        4
#define STK342X_STATE_EN_INTELL_PRST_SHIFT     3
#define STK342X_STATE_EN_WAIT_PSGS_SHIFT       2
#define STK342X_STATE_EN_ALS_SHIFT             1
#define STK342X_STATE_EN_PS_SHIFT              0

#define STK342X_STATE_EN_CT_AUTOK_MASK         0x10
#define STK342X_STATE_EN_INTELL_PRST_MASK      0x08
#define STK342X_STATE_EN_IRO_MASK              0x10
#define STK342X_STATE_EN_WAIT_PSGS_MASK        0x04
#define STK342X_STATE_EN_ALS_MASK              0x02
#define STK342X_STATE_EN_PS_MASK               0x01

/* Define PS ctrl reg */
#define STK342X_PS_PRS_SHIFT            6
#define STK342X_PS_GAIN_SHIFT           4
#define STK342X_PS_IT_SHIFT             0

#define STK342X_PS_PRS_MASK             0xC0
#define STK342X_PS_GAIN_MASK            0x30
#define STK342X_PS_IT_MASK              0x0F

/* Define ALS ctrl reg */
#define STK342X_ALS_PRS_SHIFT           6
#define STK342X_ALS_GAIN_SHIFT          4
#define STK342X_ALS_IT_SHIFT            0

#define STK342X_ALS_PRS_MASK            0xC0
#define STK342X_ALS_GAIN_MASK           0x30
#define STK342X_ALS_IT_MASK             0x0F

/* Define LED ctrl reg */
#define STK342X_LED_IRDR_SHIFT          6
#define STK342X_LED_IRDR_MASK           0xC0

/* Define interrupt reg */
#define STK342X_INT_CTRL_SHIFT          7
#define STK342X_INT_INVALID_PS_SHIFT    5
#define STK342X_INT_ALS_SHIFT           3
#define STK342X_INT_PS_SHIFT            0
#define STK342X_INT_CTRL_MASK           0x80
#define STK342X_INT_GS_MASK             0x10
#define STK342X_INT_ALS_MASK            0x08
#define STK342X_INT_PS_MASK             0x01

/* Define flag reg */
#define STK342X_FLG_ALSDR_SHIFT         7
#define STK342X_FLG_PSDR_SHIFT          6
#define STK342X_FLG_ALSINT_SHIFT        5
#define STK342X_FLG_PSINT_SHIFT         4
#define STK342X_FLG_GSINT_SHIFT         3
#define STK342X_FLG_IR_RDY_SHIFT        1
#define STK342X_FLG_NF_SHIFT            0

#define STK342X_FLG_ALSDR_MASK          0x80
#define STK342X_FLG_PSDR_MASK           0x40
#define STK342X_FLG_ALSINT_MASK         0x20
#define STK342X_FLG_PSINT_MASK          0x10
#define STK342X_FLG_GSINT_MASK          0x08
#define STK342X_FLG_IR_RDY_MASK         0x02
#define STK342X_FLG_NF_MASK             0x01

/* Define ALS CTRL-2 reg */
#define STK342X_ALSC_GAIN_SHIFT         0x04
#define STK342X_ALSC_GAIN_MASK          0x30

/* Define ALS/PS parameters */
#define STK342X_PS_PRS1                0x00
#define STK342X_PS_PRS2                0x40
#define STK342X_PS_PRS4                0x80
#define STK342X_PS_PRS8                0xC0

#define STK342X_PSGS_IT97              0x00
#define STK342X_PSGS_IT195             0x01
#define STK342X_PSGS_IT390             0x02
#define STK342X_PSGS_IT780             0x03
#define STK342X_PSGS_IT1_56            0x04
#define STK342X_PSGS_IT3_12            0x05
#define STK342X_PSGS_IT6_25            0x06

#define STK342X_ALS_PRS1               0x00
#define STK342X_ALS_PRS2               0x40
#define STK342X_ALS_PRS4               0x80
#define STK342X_ALS_PRS8               0xC0

#define STK342X_ALS_GAIN1              0x00
#define STK342X_ALS_GAIN2              0x10
#define STK342X_ALS_GAIN4              0x20

#define STK342X_ALS_IT12_5             0x00
#define STK342X_ALS_IT25               0x01
#define STK342X_ALS_IT50               0x02
#define STK342X_ALS_IT100              0x03

#define STK342X_LED_50mA               0x00
#define STK342X_LED_100mA              0x40
#define STK342X_LED_150mA              0xC0

#define STK342X_WAIT20                 0x0C
#define STK342X_WAIT50                 0x20
#define STK342X_WAIT100                0x40

#define STK342X_INTELL_20              0x32
#define STK342X_BGIR_PS_INVALID        0x28
#define STK_PS_CALI_DATA_NUM           3
#define STK342X_PS_BGIR_THRESHOLD      0x64

#define STK342X_DEFAULT_CT             6000
#define STK342X_LT_N_CT                170
#define STK342X_HT_N_CT                220
#define STK342X_PS_BOOT_THD_RATIO      2




#define STK342X_ALS_THRESHOLD           10
#define STK342X_PS_BGIR_INVALID         0x7FFF0001
#define STK342X_PS_DATA_UNAVAILABLE     0x7FFF0002
#define STK342X_CALI_FILE               "/data/misc/sensor/stkalpscali.conf"
#define STK342X_ALS_CALI_TARGET_LUX     500
#define STK342X_PS_CALI_TIMES           5
#define STK342X_PS_CALI_MAX_CROSSTALK   3000
#define STK342X_PS_CALI_DIFF            40
//�Ĵ�����
typedef struct stk342x_register_table
{
    uint8_t address;
    uint8_t value;
    uint8_t mask_bit;
} stk342x_register_table;

//�Ĵ�����ַ
typedef struct stk342x_gs_data
{
    uint16_t                    gse;
    uint16_t                    gsw;
    uint16_t                    gsn;
    uint16_t                    gss;
} stk342x_gs_data;

/* Direction definitions */
enum {
  DIR_NONE,
  DIR_LEFT,
  DIR_RIGHT,
  DIR_UP,
  DIR_DOWN,
  DIR_NEAR,
  DIR_FAR,
  DIR_ALL
};

/* State definitions */
enum {
  NA_STATE,
  NEAR_STATE,
  FAR_STATE,
  ALL_STATE
};
typedef struct gesture_data_type {
    uint8_t u_data[32];
    uint8_t d_data[32];
    uint8_t l_data[32];
    uint8_t r_data[32];
    uint8_t index;
    uint8_t total_gestures;
    uint8_t in_threshold;
    uint8_t out_threshold;
} gesture_data_type;

extern void HW_STK3420_Init(void);
extern void HW_SC7L32_Handler(void);

#endif /* MYBSP_STK3420_H_ */
